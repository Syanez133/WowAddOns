local HiddenMinimap = CreateFrame("Frame")
HiddenMinimap:RegisterEvent("PLAYER_ENTERING_WORLD")
HiddenMinimap:SetScript("OnEvent", function(...)
    MinimapCluster:Hide()
    Minimap:Hide()
end)

