local HiddenMinimap = CreateFrame("Frame")
HiddenMinimap:RegisterEvent("PLAYER_ENTERING_WORLD")
HiddenMinimap:SetScript("OnEvent", function(self, event)
  if event == "PLAYER_ENTERING_WORLD" then
  MinimapCluster:Hide()
  end
end)
